package com.homework1

import java.lang.ArithmeticException
import java.lang.Exception
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

//class HW1 {

fun main() {
    println("Problem 1:")
    arrayAndList()

    println("\n\nProblem 2:")
    workWithStrings()

    println("\nProblem 3:")
    mapToDemonstrate()

    println("\nProblem 4:")
    val numberForProb4 = listOf(1, -2, 0, 12, -17)
    for (number in numberForProb4){
        val negPos0 = numberCheck(number)
        println(" $number is $negPos0")
    }


    println("\nProblem 5:")
    greeting()

    println("\nProblem 6:")
    divideNumbers(10.0,0.0)
    divideNumbers(10.0,2.0)

    println("\nProblem 7:")
    dateTimeFormat()

    println("\n\nProblem 8:")
    val person = Person("Aram Khachatryan", 30)
    println(" Name: ${person.name}")
    println(" Age: ${person.age}")

    println("\nProblem 9:")
    val lifeStage = person.ageCategory()
    println(" Life Stage: $lifeStage")

    println("\nProblem 10:")
    lambdaFilterDemonstration()

}



fun arrayAndList(){

    val arOfNumbers = arrayOf(1,2,3,4,5)
    var lNumbers = listOf(10,20,30,40,50)
    print(" Array items: ")
    for (number in arOfNumbers){
        print("$number ")
    }
    print("\n List Items: ")
    for (number in lNumbers){
        print("$number ")
    }
}

fun workWithStrings(){
    var experString = " Deadline of homework 1"
    experString += " is October 21"
    val dateAsSubstring = experString.substring(experString.length-10)
    val lowercaseString = experString.lowercase()
    val uppercaseString = experString.uppercase()

    println(" Concatenation: $experString")
    println(" Substring: $dateAsSubstring")
    println(" Lowercase: $lowercaseString")
    println(" Uppercase: $uppercaseString")

}


fun mapToDemonstrate(){
    val ageMap = mapOf(
        "Aram" to 25,
        "Ani" to 23,
        "Atom" to 30,
        "Mariam" to 24
    )

    for ((key,value) in ageMap){
        println(" Name: $key, Age: $value")
    }
}


fun numberCheck (number: Int): String{
    return when {
        number > 0 -> "Positive"
        number < 0 -> "Negative"
        else -> "Zero"
    }
}

fun greeting(){
    print(" Enter your name: ")
    val name = readLine() ?: ""
    print(" Enter your age: ")
    val age = readLine()?.toIntOrNull() ?: 0

    val greeting = when {
        age <=0 -> "You have entered an invalid age. Please enter number greater than 0"
        else -> "Hello, $name! I am happy to know that you are already $age years old."
    }

    println(" $greeting")

}
//}

fun divideNumbers(dividend: Double, divisor: Double)  {
    val result = try{
        if (divisor == 0.0) {
            throw ArithmeticException("Division by 0 is not allowed")
        } else {
            " Result of division: ${dividend / divisor}"
        }
    } catch (e: Exception) {
        e.message ?: "An Error occurred."
    }
    println(" $result")
}

fun dateTimeFormat(){
    val currentDateTime = LocalDateTime.now()
    val formatterPattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
    val dateTimeFinal = currentDateTime.format(formatterPattern)
    print(" $dateTimeFinal")
}

class Person(
    val name: String,
    val age: Int
){
    fun ageCategory(): String {
        return when (age){
            in 0..12 -> "Child"
            in 13..19 -> "Teenager"
            else -> "Adult"
        }
    }
}

fun lambdaFilterDemonstration(){
    val lNumbers = listOf(1,2,3,4,5,6,7,8)
    val evenNumbers = lNumbers.filter{it % 2 == 0}
    print(" Even numbers: $evenNumbers")
}

